import java.util.LinkedList;
public class Recipe {
	private String title, type, category,timeUnit;
	private float time, servings;
	private boolean containNuts;
	private int stars  = 0;
	
	private String comments;
	private LinkedList<IngredientQuantity> ingredients;
	private LinkedList<InstructionSet> instructionSet;
	
/**
 * This is a simple constructor of the Recipe class.
 * @param title
 * @param type
 * @param category
 * @param time
 * @param servings
 * @param ingredients
 * @param instructionSet
 * @param comments
 * @param containNuts
 */
	
	public Recipe(String title, String type, String category,float time,String timeUnit,float servings, 
			LinkedList<IngredientQuantity> ingredients,LinkedList<InstructionSet> instructionSet, String comments,boolean containNuts){
		this.title = title;
		this.type = type;
		this.category = category;
		this.time = time;
		this.timeUnit = timeUnit;
		this.servings = servings;
		this.ingredients = ingredients;
		this.instructionSet = instructionSet;
		this.comments = comments;
		this.containNuts = containNuts;
	}
	public Recipe(){} //DUMMY METHOD NEEDS TO BE DELETED
	public void setContainNuts(boolean containNuts) {this.containNuts = containNuts;}
	public void setTitle(String title){this.title = title;}
	public void setType(String type){this.type = type;}
	public void setCategory(String category){this.category = category;}
	public void setTime(float time){this.time = time;}
	public void setServings(float servings){this.servings = servings;}
	public void setIngredients(LinkedList<IngredientQuantity> ingredients ){this.ingredients = ingredients;}
	public void setInstructionSet(LinkedList<InstructionSet> instructionSet ){this.instructionSet = instructionSet;}
	public void setTimeUnit(String timeUnit){this.timeUnit = timeUnit;}
	public void setComments(String comments){this.comments = comments;}
	
	public int getStars() {
		return stars;
	}
	public void setStars(int stars) {
		this.stars = stars;
	}
	
	public boolean isContainNuts() {return containNuts;}
	public String getTitle(){return title;}
	public String getType(){return type;}
	public String getCategory(){return category;}
	public float getTime(){return time;}
	public float getServings(){return servings;}
	public LinkedList<IngredientQuantity> getIngredients(){return ingredients;}
	public LinkedList<InstructionSet> getInstructionSet(){return instructionSet;}
	public String getTimeUnit(){return timeUnit;}
	public String getComments(){return comments;}

	public void addInstructionSet(InstructionSet set){instructionSet.add(set);} // to reverify
	

	public void addInstructionSetWithIndex(int index,InstructionSet set){instructionSet.add(index,set);} // to reverify
	
	public void addIngredientAmount(IngredientQuantity ingredient){ingredients.add(ingredient);}
	public void addIngredientAmountWithIndex(int index,IngredientQuantity ingredient){ingredients.add(index,ingredient);}
}

