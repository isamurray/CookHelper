import java.util.LinkedList;
public class Instruction {
	
	private String description, warning;
	private boolean optionnal;
	private Instruction isRequiredFor;
	private InstructionSet instructionSet;
	private LinkedList<IngredientQuantity> ingredients;
	
	

	public Instruction(String description, String warning, boolean optionnal, Instruction isRequiredFor, InstructionSet instructionSet,LinkedList<IngredientQuantity> ingredients ){
		this.isRequiredFor = isRequiredFor;
		this.description = description;
		this.warning = warning;
		this.optionnal = optionnal;
		this.instructionSet = instructionSet;
		this.ingredients = ingredients;
	}
	public void setDescription(String description){this.description = description;}
	public String getWarning() {
		return warning;
	}
	public void setWarning(String warning) {
		this.warning = warning;
	}
	public boolean isOptionnal() {
		return optionnal;
	}
	public void setOptionnal(boolean optionnal) {
		this.optionnal = optionnal;
	}
	public Instruction getIsRequiredFor() {
		return isRequiredFor;
	}
	public void setIsRequiredFor(Instruction isRequiredFor) {
		this.isRequiredFor = isRequiredFor;
	}
	public InstructionSet getInstructionSet() {
		return instructionSet;
	}
	public void setInstructionSet(InstructionSet instructionSet) {
		this.instructionSet = instructionSet;
	}
	public String getDescription() {
		return description;
	}
	public LinkedList<IngredientQuantity> getIngredients() {
		return ingredients;
	}
	public void setIngredients(LinkedList<IngredientQuantity> ingredients) {
		this.ingredients = ingredients;
	}
}
