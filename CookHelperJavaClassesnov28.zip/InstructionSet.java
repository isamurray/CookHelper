import java.util.LinkedList;
public class InstructionSet {
	private LinkedList<Instruction> instructions;
	private String description, timeUnit;
	private float time;
	private Recipe recipeLink;

	public InstructionSet(LinkedList<Instruction> instructions, String description, float time, String timeUnit,Recipe recipeLink){
		this.instructions = instructions;
		this.description = description;
		this.time = time;
		this.timeUnit=timeUnit;
		this.recipeLink = recipeLink;
		
	}
	public void setInstructions(LinkedList<Instruction> instructions){this.instructions = instructions;}
	public void setDescription(String description){this.description = description;}
	public void setTime(float time){this.time = time;}
	public void setTimeUnit(String timeUnit){this.timeUnit = timeUnit;}
	public void setRecipeLink(Recipe recipeLink){this.recipeLink = recipeLink;}
	
	public String getDescription(){return description;}
	public String getTimeUnit(){return timeUnit;}
	public LinkedList<Instruction> getInstructions(){return instructions;}
	public float getTime(){return time;}
	public Recipe getRecipeLink(){return recipeLink;}
	
	public void addInstruction(Instruction instruction){instructions.add(instruction);}
	public void addInstructionByIndex(int index,Instruction instruction ){instructions.add(index,instruction);}
	
	
	public String getTotalRequiredTime(){
		return recipeLink.getTime() + recipeLink.getTimeUnit();
	}
}
