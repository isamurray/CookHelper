import java.util.LinkedList;
public class Ingredient {
	private String name;
	private boolean perishable;
	private LinkedList<IngredientQuantity> occurances;
	
	
	public Ingredient(String name, boolean perishable, LinkedList<IngredientQuantity> occurances){
		this.name = name;
		this.perishable = perishable;
		this.occurances = occurances;
				
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isPerishable() {
		return perishable;
	}
	public void setPerishable(boolean perishable) {
		this.perishable = perishable;
	}
	public LinkedList<IngredientQuantity> getOccurances() {
		return occurances;
	}
	public void setOccurances(LinkedList<IngredientQuantity> occurances) {
		this.occurances = occurances;
	}
	
}
